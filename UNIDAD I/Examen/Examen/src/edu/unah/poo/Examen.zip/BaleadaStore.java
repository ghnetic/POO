package edu.unah.poo;

public class BaleadaStore {

}
