package edu.unah.poo;

public interface Food {
	public String getName();
	public int getCalories();
	public int getPrice();
}

//Se coloco int debido a que los valores que 
//me dio en el examen son todos enteros. 
