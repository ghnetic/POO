package edu.unah.poo;

public class ThickDough extends Baleada {
	
	@Override
	public String getName() {
		return "thick dough";
	}

	@Override
	public int getCalories() {
		return 100;
	}

	@Override
	public int getPrice() {
		return 5;
	}
}
